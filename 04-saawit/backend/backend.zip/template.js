'use strict'

const loginUser = async (req, res, next) => {

  try {
    
    
  } catch (err) {
    next(err);
  }

}

module.exports = loginUser;