export function getRandomId() {
    return Math.floor(Math.random() * Date.now());
}
